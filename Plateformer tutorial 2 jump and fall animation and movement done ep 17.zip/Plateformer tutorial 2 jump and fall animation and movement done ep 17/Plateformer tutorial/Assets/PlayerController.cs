﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
public Rigidbody2D rb;
public Animator anim;
 private enum State{idle,running,jumping,falling}
private State state = State.idle;
private Collider2D coll;
public LayerMask ground;

public void Start(){
coll=GetComponent<Collider2D>();
}

   private void Update(){

       if(Input.GetKey(KeyCode.A)){
       rb.velocity=new Vector2(-5,rb.velocity.y);
       transform.localScale= new Vector2(-1,1);
	   }

      else if(Input.GetKey(KeyCode.D)){
       rb.velocity=new Vector2(5,rb.velocity.y);
        transform.localScale= new Vector2(1,1);
	   }

       else{
        
	   }

       if(Input.GetKeyDown(KeyCode.Space)&& coll.IsTouchingLayers(ground)){
       rb.velocity=new Vector2(rb.velocity.x,7.5f);
       state=State.jumping;
	   }
       VelocityState();
       anim.SetInteger("state",(int)state);
   }

   private void VelocityState(){

   if(state==State.jumping){
   if(rb.velocity.y<.1f){
       state=State.falling;
   }
   }
   else if(state==State.falling){
       if(coll.IsTouchingLayers(ground)){
        state=State.idle;
	   }
   }

   else if(Mathf.Abs(rb.velocity.x)>2f){
   //moving
   state=State.running;

   }

   else{
       state=State.idle;
   }
   
   } 
  
}
