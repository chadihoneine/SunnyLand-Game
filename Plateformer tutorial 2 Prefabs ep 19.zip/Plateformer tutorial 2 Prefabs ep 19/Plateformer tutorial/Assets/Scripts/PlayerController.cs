﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
//Start() variables
public Rigidbody2D rb;
public Animator anim;
private Collider2D coll;

//Finite State Machine
 private enum State{idle,running,jumping,falling}
private State state = State.idle;

//Inspector variables
public LayerMask ground;
public float speed=5f;
public float jumpForce=10f;

public void Start(){
coll=GetComponent<Collider2D>();
}

   private void Update(){

       Movement();
       AnimationState();
       anim.SetInteger("state",(int)state);//sets animation based on Emulator state
   }

   private void Movement(){
   if(Input.GetKey(KeyCode.A)){
       rb.velocity=new Vector2(-speed,rb.velocity.y);
       transform.localScale= new Vector2(-1,1);
	   }

      else if(Input.GetKey(KeyCode.D)){
       rb.velocity=new Vector2(speed,rb.velocity.y);
        transform.localScale= new Vector2(1,1);
	   }


       if(Input.GetKeyDown(KeyCode.Space)&& coll.IsTouchingLayers(ground)){
       rb.velocity=new Vector2(rb.velocity.x,jumpForce);
       state=State.jumping;
	   }
   }

   private void AnimationState(){

   if(state==State.jumping){
   if(rb.velocity.y<.1f){
       state=State.falling;
   }
   }
   else if(state==State.falling){
       if(coll.IsTouchingLayers(ground)){
        state=State.idle;
	   }
   }

   else if(Mathf.Abs(rb.velocity.x)>2f){
   //moving
   state=State.running;

   }

   else{
       state=State.idle;
   }
   
   } 
  
}
